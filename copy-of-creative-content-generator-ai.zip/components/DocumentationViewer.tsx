
import React from 'react';
import { DOCUMENTATION_CONTENT } from '../constants';
import { DocumentationSection } from '../types';
import Modal from './shared/Modal';

interface DocumentationViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

const DocumentationViewer: React.FC<DocumentationViewerProps> = ({ isOpen, onClose }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Technical Documentation & App Info" size="xl">
      <div className="space-y-6">
        {DOCUMENTATION_CONTENT.map((section: DocumentationSection) => (
          <section key={section.id} className="p-4 bg-slate-800/50 rounded-lg shadow">
            <h2 className="text-2xl font-bold mb-3 text-sky-500 border-b border-slate-700 pb-2">{section.title}</h2>
            <div dangerouslySetInnerHTML={{ __html: section.content }} className="prose prose-sm prose-invert max-w-none text-slate-300" />
          </section>
        ))}
      </div>
    </Modal>
  );
};

export default DocumentationViewer;
    