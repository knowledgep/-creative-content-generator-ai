
import React, { useState, useCallback, useEffect } from 'react';
import { PromptTemplate, CustomizationField, GeneratedContent, PerformanceMetrics } from './types';
import { PROMPT_TEMPLATES } from './constants';
import { generateCreativeContent, GeminiResponse } from './services/geminiService';
import Button from './components/shared/Button';
import DocumentationViewer from './components/DocumentationViewer';
import { Lightbulb, BookOpen, Save, Copy, Trash2, Info, ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';

const App: React.FC = () => {
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(PROMPT_TEMPLATES[0].id);
  const [customizations, setCustomizations] = useState<Record<string, string | number>>({});
  const [generatedResult, setGeneratedResult] = useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics | null>(null);
  const [savedResults, setSavedResults] = useState<GeneratedContent[]>([]);
  const [isDocsOpen, setIsDocsOpen] = useState<boolean>(false);
  const [showSavedResults, setShowSavedResults] = useState<boolean>(true);

  const currentTemplate = PROMPT_TEMPLATES.find(t => t.id === selectedTemplateId) || PROMPT_TEMPLATES[0];

  useEffect(() => {
    // Initialize customizations when template changes
    const initialCustomizations: Record<string, string | number> = {};
    currentTemplate.customizations.forEach(field => {
      initialCustomizations[field.id] = field.defaultValue !== undefined ? field.defaultValue : '';
    });
    setCustomizations(initialCustomizations);
    setGeneratedResult(null); // Clear previous result when template changes
    setError(null);
  }, [selectedTemplateId, currentTemplate]);

  const handleCustomizationChange = (id: string, value: string | number) => {
    setCustomizations(prev => ({ ...prev, [id]: value }));
  };

  const constructPrompt = useCallback((): string => {
    let prompt = currentTemplate.basePrompt;
    for (const key in customizations) {
      const placeholder = `{{${key}}}`;
      prompt = prompt.replace(new RegExp(placeholder, 'g'), String(customizations[key]));
    }
    // Add a general instruction for quality and safety
    prompt += "\n\nPlease ensure the output is creative, well-written, and adheres to safety guidelines, avoiding any harmful or inappropriate content.";
    return prompt;
  }, [currentTemplate, customizations]);

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedResult(null);
    setPerformanceMetrics(null);

    const finalPrompt = constructPrompt();
    const startTime = Date.now();

    try {
      const response: GeminiResponse = await generateCreativeContent(finalPrompt);
      const endTime = Date.now();
      const generationTimeMs = endTime - startTime;

      const currentPromptTokens = response.usageMetadata?.promptTokenCount;
      const currentTotalTokens = response.usageMetadata?.totalTokenCount;
      let currentCandidateTokens: number | undefined = undefined;

      if (currentTotalTokens !== undefined && currentPromptTokens !== undefined) {
        currentCandidateTokens = currentTotalTokens - currentPromptTokens;
      }

      const newResult: GeneratedContent = {
        id: Date.now().toString(),
        prompt: finalPrompt,
        content: response.text,
        templateName: currentTemplate.name,
        timestamp: new Date(),
        generationTimeMs,
        promptTokens: currentPromptTokens,
        candidateTokens: currentCandidateTokens,
      };
      setGeneratedResult(newResult);
      
      setPerformanceMetrics({
        generationTimeMs,
        promptTokens: currentPromptTokens,
        candidateTokens: currentCandidateTokens,
        totalTokens: currentTotalTokens 
      });

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred.');
      }
      console.error("Generation error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [constructPrompt, currentTemplate]);

  const handleSaveResult = () => {
    if (generatedResult) {
      setSavedResults(prev => [generatedResult, ...prev.slice(0, 9)]); // Keep last 10 results
      setGeneratedResult(null); // Clear current result after saving
      setPerformanceMetrics(null);
    }
  };
  
  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => alert('Content copied to clipboard!'))
      .catch(err => console.error('Failed to copy: ', err));
  };

  const removeSavedResult = (id: string) => {
    setSavedResults(prev => prev.filter(r => r.id !== id));
  };


  const renderCustomizationField = (field: CustomizationField) => {
    const value = customizations[field.id] !== undefined ? customizations[field.id] : (field.defaultValue !== undefined ? field.defaultValue : '');
    const commonInputClasses = "w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md focus:ring-sky-500 focus:border-sky-500 placeholder-slate-400 text-slate-100 transition-colors";

    switch (field.type) {
      case 'text':
        return <input type="text" value={String(value)} onChange={(e) => handleCustomizationChange(field.id, e.target.value)} placeholder={field.placeholder} className={commonInputClasses} />;
      case 'textarea':
        return <textarea value={String(value)} onChange={(e) => handleCustomizationChange(field.id, e.target.value)} placeholder={field.placeholder} rows={3} className={commonInputClasses} />;
      case 'number':
        return <input type="number" value={String(value)} onChange={(e) => handleCustomizationChange(field.id, parseInt(e.target.value, 10) || 0)} min={field.min} max={field.max} placeholder={field.placeholder} className={commonInputClasses} />;
      case 'select':
        return (
          <select value={String(value)} onChange={(e) => handleCustomizationChange(field.id, e.target.value)} className={`${commonInputClasses} appearance-none`}>
            {field.options?.map(option => <option key={option} value={option}>{option}</option>)}
          </select>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col p-4 md:p-6 lg:p-8 space-y-6 bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100" style={{ fontFamily: "'Inter', sans-serif" }}>
      <header className="flex flex-col sm:flex-row justify-between items-center pb-4 border-b border-slate-700">
        <h1 className="text-3xl sm:text-4xl font-bold text-sky-400 mb-2 sm:mb-0" style={{ fontFamily: "'Lora', serif" }}>
          Creative Content Generator <span className="text-sky-600">AI</span>
        </h1>
        <Button onClick={() => setIsDocsOpen(true)} variant="ghost" size="sm" leftIcon={<Info size={18} />}>
          App Info & Docs
        </Button>
      </header>

      {error && (
        <div className="p-4 bg-red-800/50 border border-red-700 text-red-200 rounded-md flex items-center">
          <AlertTriangle size={20} className="mr-2 text-red-400" />
          <strong>Error:</strong> {error}
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-6 flex-grow">
        {/* Left Panel: Controls */}
        <div className="lg:w-1/3 bg-slate-800/70 p-6 rounded-xl shadow-2xl flex flex-col space-y-6 h-fit lg:sticky lg:top-8">
          <div>
            <label htmlFor="template-select" className="block text-sm font-medium text-sky-300 mb-1">Select Template</label>
            <div className="relative">
              <select
                id="template-select"
                value={selectedTemplateId}
                onChange={(e) => setSelectedTemplateId(e.target.value)}
                className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-sky-500 focus:border-sky-500 text-slate-100 appearance-none pr-8"
              >
                {PROMPT_TEMPLATES.map(template => (
                  <option key={template.id} value={template.id}>{template.name} ({template.category})</option>
                ))}
              </select>
              <ChevronDown size={20} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
            <p className="mt-1 text-xs text-slate-400">{currentTemplate.description}</p>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-sky-400 border-b border-slate-700 pb-2">Customization Parameters</h3>
            {currentTemplate.customizations.map(field => (
              <div key={field.id}>
                <label htmlFor={field.id} className="block text-sm font-medium text-slate-300 mb-1">{field.label}</label>
                {renderCustomizationField(field)}
              </div>
            ))}
          </div>
          
          <Button onClick={handleGenerate} isLoading={isLoading} size="lg" className="w-full" leftIcon={<Lightbulb size={20} />}>
            Generate Content
          </Button>
        </div>

        {/* Right Panel: Output & Saved */}
        <div className="lg:w-2/3 flex flex-col space-y-6">
          {/* Generated Content */}
          {(isLoading || generatedResult || performanceMetrics) && (
            <div className="bg-slate-800/70 p-6 rounded-xl shadow-2xl">
              <h2 className="text-2xl font-semibold text-sky-400 mb-4 border-b border-slate-700 pb-2">Generated Output</h2>
              {isLoading && <div className="flex justify-center items-center py-10"><Button isLoading={true} variant="ghost">Generating...</Button></div>}
              
              {generatedResult && !isLoading && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-900/50 rounded-md max-h-96 overflow-y-auto prose prose-sm prose-invert max-w-none pretty-scrollbar">
                    <pre className="whitespace-pre-wrap font-sans text-slate-200">{generatedResult.content}</pre>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button onClick={handleSaveResult} variant="secondary" size="sm" leftIcon={<Save size={16}/>}>Save Result</Button>
                    <Button onClick={() => handleCopyToClipboard(generatedResult.content)} variant="ghost" size="sm" leftIcon={<Copy size={16}/>}>Copy Text</Button>
                  </div>
                </div>
              )}
              {performanceMetrics && !isLoading && (
                <div className="mt-4 p-3 bg-slate-700/50 rounded-md text-xs text-slate-300 space-y-1">
                  <p><strong>Generation Time:</strong> {(performanceMetrics.generationTimeMs / 1000).toFixed(2)}s</p>
                  {performanceMetrics.promptTokens !== undefined && <p><strong>Prompt Tokens:</strong> {performanceMetrics.promptTokens}</p>}
                  {performanceMetrics.candidateTokens !== undefined && <p><strong>Output Tokens:</strong> {performanceMetrics.candidateTokens}</p>}
                  {performanceMetrics.totalTokens !== undefined && <p><strong>Total Tokens:</strong> {performanceMetrics.totalTokens}</p>}
                </div>
              )}
            </div>
          )}

          {/* Saved Results */}
          <div className="bg-slate-800/70 p-6 rounded-xl shadow-2xl">
            <div 
                className="flex justify-between items-center cursor-pointer border-b border-slate-700 pb-2 mb-4"
                onClick={() => setShowSavedResults(!showSavedResults)}
            >
                <h2 className="text-2xl font-semibold text-sky-400">Saved Results ({savedResults.length})</h2>
                {showSavedResults ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
            </div>

            {showSavedResults && (
              savedResults.length > 0 ? (
                <div className="space-y-4 max-h-[600px] overflow-y-auto pretty-scrollbar pr-2">
                  {savedResults.map(result => (
                    <div key={result.id} className="p-4 bg-slate-900/50 rounded-md relative group">
                       <button 
                        onClick={() => removeSavedResult(result.id)}
                        className="absolute top-2 right-2 p-1 bg-red-700/50 hover:bg-red-600 rounded-full text-red-200 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete this result"
                      >
                        <Trash2 size={16} />
                      </button>
                      <h4 className="font-semibold text-sky-500 text-sm">{result.templateName}</h4>
                      <p className="text-xs text-slate-500 mb-1">{result.timestamp.toLocaleString()}</p>
                      <div className="max-h-32 overflow-y-auto text-sm text-slate-300 prose prose-xs prose-invert max-w-none pretty-scrollbar mb-2">
                         <pre className="whitespace-pre-wrap font-sans">{result.content.substring(0, 300)}{result.content.length > 300 ? '...' : ''}</pre>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => handleCopyToClipboard(result.content)} variant="ghost" size="sm" leftIcon={<Copy size={14}/>}>Copy</Button>
                        <Button 
                            onClick={() => {
                                setGeneratedResult(result); 
                                const savedPromptTokens = result.promptTokens;
                                const savedCandidateTokens = result.candidateTokens;
                                let savedTotalTokens: number | undefined = undefined;
                                if (savedPromptTokens !== undefined && savedCandidateTokens !== undefined) {
                                    savedTotalTokens = savedPromptTokens + savedCandidateTokens;
                                } else if (savedPromptTokens !== undefined) {
                                    savedTotalTokens = savedPromptTokens;
                                } else if (savedCandidateTokens !== undefined ) {
                                    savedTotalTokens = savedCandidateTokens;
                                }


                                setPerformanceMetrics({ 
                                    generationTimeMs: result.generationTimeMs || 0, 
                                    promptTokens: savedPromptTokens, 
                                    candidateTokens: savedCandidateTokens,
                                    totalTokens: savedTotalTokens 
                                });
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                            }} 
                            variant="ghost" 
                            size="sm"
                            leftIcon={<BookOpen size={14}/>}
                        >
                            View Full
                        </Button>
                      </div>
                       {result.generationTimeMs !== undefined && (
                        <p className="text-xs text-slate-500 mt-1 pt-1 border-t border-slate-700/50">
                          Time: {(result.generationTimeMs / 1000).toFixed(2)}s
                          {result.promptTokens !== undefined && `, P.Tokens: ${result.promptTokens}`}
                          {result.candidateTokens !== undefined && `, O.Tokens: ${result.candidateTokens}`}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400 italic">No results saved yet. Generated content will appear here once you save it.</p>
              )
            )}
          </div>
        </div>
      </div>
      
      <DocumentationViewer isOpen={isDocsOpen} onClose={() => setIsDocsOpen(false)} />
      <style>{`
        .pretty-scrollbar::-webkit-scrollbar { width: 6px; }
        .pretty-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .pretty-scrollbar::-webkit-scrollbar-thumb { background: #475569; border-radius: 3px; }
        .pretty-scrollbar::-webkit-scrollbar-thumb:hover { background: #64748b; }
        .prose { font-family: 'Lora', serif; }
        .prose pre { font-family: 'Inter', sans-serif; background-color: transparent !important; padding: 0 !important; margin:0 !important; }
      `}</style>
    </div>
  );
};

export default App;
