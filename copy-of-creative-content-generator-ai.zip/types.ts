
export interface CustomizationField {
  id: string;
  label: string;
  type: 'text' | 'select' | 'textarea' | 'number';
  options?: string[];
  placeholder?: string;
  defaultValue?: string | number;
  min?: number;
  max?: number;
}

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  category: 'Story' | 'Poem' | 'Other';
  basePrompt: string; // The core prompt text, can include placeholders like {{keyword}}
  customizations: CustomizationField[];
}

export interface GeneratedContent {
  id: string;
  prompt: string;
  content: string;
  templateName: string;
  timestamp: Date;
  generationTimeMs?: number;
  promptTokens?: number;
  candidateTokens?: number;
}

export interface PerformanceMetrics {
  generationTimeMs: number;
  promptTokens?: number;
  candidateTokens?: number;
  totalTokens?: number;
}

export interface DocumentationSection {
  id: string;
  title: string;
  content: string; // HTML or Markdown string
}

export enum ContentLength {
  Short = "Short (approx. 100-200 words)",
  Medium = "Medium (approx. 300-500 words)",
  Long = "Long (approx. 700-1000 words)",
}

export enum StoryGenre {
  Fantasy = "Fantasy",
  SciFi = "Science Fiction",
  Mystery = "Mystery",
  Romance = "Romance",
  Thriller = "Thriller",
  Humor = "Humor",
  Historical = "Historical Fiction",
}

export enum PoemType {
  Haiku = "Haiku",
  Sonnet = "Sonnet",
  Limerick = "Limerick",
  FreeVerse = "Free Verse",
  Ballad = "Ballad"
}

export enum WritingStyle {
  Formal = "Formal",
  Informal = "Informal",
  Poetic = "Poetic",
  Academic = "Academic",
  Journalistic = "Journalistic",
  Whimsical = "Whimsical"
}
    