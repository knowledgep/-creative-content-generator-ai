
import { GoogleGenAI, GenerateContentResponse, UsageMetadata } from "@google/genai";
import { GEMINI_MODEL_NAME } from '../constants';

// Ensure API_KEY is handled by the build/environment process
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY for Gemini is not set. Please ensure the API_KEY environment variable is configured.");
  // In a real app, you might want to throw an error or disable API-dependent features.
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "YOUR_API_KEY_PLACEHOLDER" }); // Fallback for type safety, but should be set

export interface GeminiResponse {
  text: string;
  usageMetadata?: UsageMetadata;
}

export async function generateCreativeContent(prompt: string): Promise<GeminiResponse> {
  if (!API_KEY) {
    throw new Error("Gemini API Key not configured. Cannot generate content.");
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      // config: { // Optional: add thinkingConfig or other parameters if needed for specific use cases
      //   thinkingConfig: { thinkingBudget: 0 } // Example: disable thinking for lower latency
      // }
    });
    
    const text = response.text;
    const usageMetadata = response.usageMetadata;

    return { text, usageMetadata };

  } catch (error) {
    console.error("Error generating content with Gemini API:", error);
    if (error instanceof Error) {
        // Attempt to parse Google specific errors if possible, or use a generic message
        const googleError = error as any; // Cast to any to check for specific properties
        if (googleError.message && googleError.message.includes('API key not valid')) {
            throw new Error("Invalid API Key. Please check your Gemini API key configuration.");
        }
        if (googleError.message && googleError.message.includes('quota')) {
            throw new Error("API quota exceeded. Please check your Gemini API usage limits.");
        }
        throw new Error(`Failed to generate content: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating content.");
  }
}
    