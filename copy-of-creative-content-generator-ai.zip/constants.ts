
import { PromptTemplate, DocumentationSection, StoryGenre, ContentLength, PoemType, WritingStyle } from './types';

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export const PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: 'story-generic',
    name: 'Generic Story Idea',
    description: 'Generate a short story based on a theme and keywords.',
    category: 'Story',
    basePrompt: `Write a {{length}} story in the {{genre}} genre. The story should revolve around the theme of "{{theme}}" and incorporate the keywords: {{keywords}}. Make it engaging and {{style}}.`,
    customizations: [
      { id: 'genre', label: 'Genre', type: 'select', options: Object.values(StoryGenre), defaultValue: StoryGenre.Fantasy },
      { id: 'theme', label: 'Main Theme', type: 'text', placeholder: 'e.g., courage, betrayal, discovery', defaultValue: 'discovery' },
      { id: 'keywords', label: 'Keywords (comma-separated)', type: 'text', placeholder: 'e.g., ancient map, hidden cave, magical artifact', defaultValue: 'ancient map, hidden cave' },
      { id: 'length', label: 'Story Length', type: 'select', options: Object.values(ContentLength), defaultValue: ContentLength.Short },
      { id: 'style', label: 'Writing Style', type: 'select', options: Object.values(WritingStyle), defaultValue: WritingStyle.Informal },
    ],
  },
  {
    id: 'poem-themed',
    name: 'Themed Poem',
    description: 'Create a poem about a specific subject with a chosen style and structure.',
    category: 'Poem',
    basePrompt: `Compose a {{poemType}} about "{{subject}}". It should have approximately {{numberOfLines}} lines and follow a {{rhymeScheme}} rhyme scheme if applicable for the type. The tone should be {{tone}}.`,
    customizations: [
      { id: 'poemType', label: 'Poem Type', type: 'select', options: Object.values(PoemType), defaultValue: PoemType.FreeVerse },
      { id: 'subject', label: 'Subject of Poem', type: 'text', placeholder: 'e.g., a sunset, a bustling city, solitude', defaultValue: 'a sunset' },
      { id: 'numberOfLines', label: 'Approx. Number of Lines', type: 'number', defaultValue: 12, min: 4, max: 100 },
      { id: 'rhymeScheme', label: 'Rhyme Scheme (e.g., AABB, ABAB, or "None")', type: 'text', placeholder: 'AABB, ABAB, None', defaultValue: 'None' },
      { id: 'tone', label: 'Tone', type: 'select', options: ['Joyful', 'Melancholy', 'Reflective', 'Humorous', 'Serious'], defaultValue: 'Reflective' },
    ],
  },
  {
    id: 'character-backstory',
    name: 'Character Backstory',
    description: 'Develop a backstory for a fictional character.',
    category: 'Story',
    basePrompt: `Create a detailed backstory for a character named {{name}}. They are a {{role}} in a {{genreSetting}} setting. Focus on a pivotal event: "{{pivotalEvent}}". Their primary motivation is {{motivation}}. The backstory should be {{length}} and written in a {{style}} style.`,
    customizations: [
      { id: 'name', label: 'Character Name', type: 'text', placeholder: 'e.g., Elara, Jax, Professor Armitage', defaultValue: 'Elara' },
      { id: 'role', label: 'Character Role/Archetype', type: 'text', placeholder: 'e.g., reluctant hero, wise mentor, cunning villain', defaultValue: 'reluctant hero' },
      { id: 'genreSetting', label: 'Genre/Setting', type: 'text', placeholder: 'e.g., cyberpunk city, medieval kingdom, space opera', defaultValue: 'medieval kingdom' },
      { id: 'pivotalEvent', label: 'Pivotal Event', type: 'textarea', placeholder: 'Describe a key event that shaped them.', defaultValue: 'the loss of their family heirloom' },
      { id: 'motivation', label: 'Primary Motivation', type: 'text', placeholder: 'e.g., to find redemption, to seek revenge, to protect the innocent', defaultValue: 'to find redemption' },
      { id: 'length', label: 'Backstory Length', type: 'select', options: Object.values(ContentLength), defaultValue: ContentLength.Medium },
      { id: 'style', label: 'Writing Style', type: 'select', options: Object.values(WritingStyle), defaultValue: WritingStyle.Formal },
    ],
  },
  {
    id: 'world-description',
    name: 'Fictional World Snippet',
    description: 'Generate a descriptive snippet of a fictional world.',
    category: 'Story',
    basePrompt: `Describe a unique location called "{{locationName}}" in a {{worldType}} world. Focus on its {{sensoryDetails}} (sights, sounds, smells). What makes it {{uniqueFeature}}? The description should be {{length}} and evoke a sense of {{mood}}.`,
    customizations: [
      { id: 'locationName', label: 'Location Name', type: 'text', placeholder: 'e.g., The Whispering Glades, Neo-Kyoto Sector 7', defaultValue: 'The Crystal Caves' },
      { id: 'worldType', label: 'Type of World', type: 'text', placeholder: 'e.g., high fantasy, post-apocalyptic, steampunk', defaultValue: 'high fantasy' },
      { id: 'sensoryDetails', label: 'Key Sensory Details', type: 'textarea', placeholder: 'e.g., shimmering crystals, echoing drips, cool damp air', defaultValue: 'shimmering crystals, echoing drips' },
      { id: 'uniqueFeature', label: 'Unique Feature', type: 'text', placeholder: 'e.g., plants that glow, gravity-defying structures', defaultValue: 'crystals that hum with ancient energy' },
      { id: 'length', label: 'Description Length', type: 'select', options: Object.values(ContentLength), defaultValue: ContentLength.Short },
      { id: 'mood', label: 'Desired Mood', type: 'select', options: ['Mysterious', 'Peaceful', 'Dangerous', 'Awe-inspiring', 'Gloomy'], defaultValue: 'Mysterious' },
    ],
  },
  {
    id: 'dialogue-snippet',
    name: 'Dialogue Snippet',
    description: 'Create a short dialogue between two characters.',
    category: 'Story',
    basePrompt: `Write a short dialogue snippet between {{char1Name}} ({{char1Desc}}) and {{char2Name}} ({{char2Desc}}). They are discussing "{{topic}}". The dialogue should reveal {{subtext}} and have a {{tone}} tone. Aim for about {{lineCount}} lines of dialogue.`,
    customizations: [
      { id: 'char1Name', label: 'Character 1 Name', type: 'text', placeholder: 'e.g., Captain Eva', defaultValue: 'Marcus' },
      { id: 'char1Desc', label: 'Character 1 Description', type: 'text', placeholder: 'e.g., a gruff space pirate', defaultValue: 'a weary detective' },
      { id: 'char2Name', label: 'Character 2 Name', type: 'text', placeholder: 'e.g., RX-8 (an android)', defaultValue: 'Silas' },
      { id: 'char2Desc', label: 'Character 2 Description', type: 'text', placeholder: 'e.g., a calm, logical AI', defaultValue: 'a nervous informant' },
      { id: 'topic', label: 'Topic of Discussion', type: 'text', placeholder: 'e.g., a recent heist, a moral dilemma', defaultValue: 'a mysterious message' },
      { id: 'subtext', label: 'Subtext to Reveal', type: 'text', placeholder: 'e.g., mistrust between them, a hidden agenda', defaultValue: 'their shared fear' },
      { id: 'tone', label: 'Dialogue Tone', type: 'select', options: ['Tense', 'Humorous', 'Informative', 'Emotional', 'Suspicious'], defaultValue: 'Tense' },
      { id: 'lineCount', label: 'Approx. Lines of Dialogue', type: 'number', defaultValue: 8, min:4, max: 20 },
    ],
  },
];

export const DOCUMENTATION_CONTENT: DocumentationSection[] = [
  {
    id: 'architecture',
    title: 'Implementation Architecture & API Selection',
    content: `
      <h3 class="text-xl font-semibold mb-2 text-sky-400">Implementation Architecture</h3>
      <p class="mb-2">This application is a single-page React application built with TypeScript and styled using Tailwind CSS. It follows a component-based architecture:</p>
      <ul class="list-disc list-inside mb-3 space-y-1">
        <li><strong>App.tsx:</strong> Main component, manages global state and layout.</li>
        <li><strong>components/:</strong> Contains reusable UI components for prompt selection, customization, content display, performance metrics, and documentation.</li>
        <li><strong>services/geminiService.ts:</strong> Handles all interactions with the Google Gemini API.</li>
        <li><strong>types.ts:</strong> Defines shared TypeScript types and interfaces.</li>
        <li><strong>constants.ts:</strong> Stores static data like prompt templates and documentation content.</li>
      </ul>
      <p class="mb-2">State management relies on React Hooks (<code>useState</code>, <code>useCallback</code>, <code>useEffect</code>). API calls are asynchronous, with loading and error states handled in the UI.</p>
      
      <h3 class="text-xl font-semibold mt-4 mb-2 text-sky-400">API Selection Rationale</h3>
      <p class="mb-2">The <strong>Google Gemini API</strong> (specifically the <code>gemini-2.5-flash-preview-04-17</code> model) was chosen for several reasons:</p>
      <ul class="list-disc list-inside space-y-1">
        <li><strong>Advanced Capabilities:</strong> Gemini models are highly capable in creative text generation, understanding context, and following complex instructions.</li>
        <li><strong>Performance:</strong> The 'flash' variant is optimized for lower latency, making it suitable for interactive applications.</li>
        <li><strong>Flexibility:</strong> The API supports various parameters for fine-tuning outputs, which is essential for a creative generation tool.</li>
        <li><strong>Developer Experience:</strong> The <code>@google/genai</code> SDK provides a straightforward way to integrate the API into JavaScript/TypeScript applications.</li>
      </ul>
    `,
  },
  {
    id: 'prompt-engineering',
    title: 'Prompt Engineering Methodology & Performance',
    content: `
      <h3 class="text-xl font-semibold mb-2 text-sky-400">Prompt Engineering Methodology</h3>
      <p class="mb-2">Our prompt engineering approach focuses on clarity, specificity, and iterative refinement:</p>
      <ul class="list-disc list-inside mb-3 space-y-1">
        <li><strong>Structured Templates:</strong> We use base templates with placeholders (e.g., <code>{{genre}}</code>, <code>{{theme}}</code>) that are dynamically filled by user customizations. This provides consistency while allowing flexibility.</li>
        <li><strong>Role Play:</strong> Prompts often implicitly or explicitly ask the AI to adopt a role (e.g., "Write a story...", "Compose a poem...").</li>
        <li><strong>Clear Instructions:</strong> We specify desired output format, length, style, and key elements to include.</li>
        <li><strong>Parameterization:</strong> Users can adjust parameters like genre, length, keywords, poem type, etc., which directly influence the final prompt sent to the API.</li>
        <li><strong>Iterative Design:</strong> The provided templates are starting points. Effective prompt engineering often involves experimenting with different phrasings and parameters to achieve desired results. (The "Comparison Matrix" below gives an idea of how template variations lead to different outputs).</li>
      </ul>

      <h3 class="text-xl font-semibold mt-4 mb-2 text-sky-400">Performance Optimization Techniques</h3>
      <ul class="list-disc list-inside space-y-1">
        <li><strong>Model Selection:</strong> Using <code>gemini-2.5-flash-preview-04-17</code> which is optimized for speed.</li>
        <li><strong>Client-Side Processing:</strong> Minimizing complex logic on the client to keep the UI responsive.
        <li><strong>Asynchronous Operations:</strong> API calls are made asynchronously to prevent UI blocking. Loading indicators provide user feedback.</li>
        <li><strong>Memoization:</strong> React's <code>useCallback</code> and <code>React.memo</code> (where appropriate, though not heavily used in this version) can prevent unnecessary re-renders of components.</li>
        <li><strong>Efficient State Management:</strong> Using React state judiciously to trigger re-renders only when necessary.</li>
      </ul>
    `,
  },
  {
    id: 'usage-info',
    title: 'Rate Limits, Costs, Samples & Comparison',
    content: `
      <h3 class="text-xl font-semibold mb-2 text-sky-400">API Rate Limits & Usage Costs</h3>
      <p class="mb-2">The Google Gemini API has usage quotas and pricing that depend on the model used and the volume of requests. As of the current model (<code>gemini-2.5-flash-preview-04-17</code>):</p>
      <ul class="list-disc list-inside mb-3 space-y-1">
        <li><strong>Rate Limits:</strong> Typically, there are requests per minute (RPM) and tokens per minute (TPM) limits. For <code>gemini-2.5-flash-preview-04-17</code>, common default limits might be around 60 RPM. These can vary based on your Google Cloud project and region.</li>
        <li><strong>Pricing:</strong> Pricing is generally based on the number of input (prompt) and output (candidate) characters or tokens. For example, pricing might be specified per 1,000 characters or 1,000 tokens.</li>
        <li><strong>Free Tier:</strong> Google often provides a free tier for initial usage.</li>
      </ul>
      <p class="mb-2"><strong>Important:</strong> Always refer to the <a href="https://ai.google.dev/pricing" target="_blank" rel="noopener noreferrer" class="text-sky-400 hover:text-sky-300 underline">official Google Cloud AI documentation</a> for the most up-to-date and specific information on rate limits and pricing for your account and region.</p>
      <p class="mb-2">This tool tracks generation time and token usage (if available from API response) per request, but does not calculate actual costs.</p>

      <h3 class="text-xl font-semibold mt-4 mb-2 text-sky-400">Prompt Template Comparison Matrix (Conceptual)</h3>
      <table class="w-full text-left border-collapse border border-slate-500 mb-3">
        <thead>
          <tr>
            <th class="border border-slate-600 p-2 bg-slate-700">Template Name</th>
            <th class="border border-slate-600 p-2 bg-slate-700">Primary Goal</th>
            <th class="border border-slate-600 p-2 bg-slate-700">Key Customizations</th>
            <th class="border border-slate-600 p-2 bg-slate-700">Expected Output Style</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="border border-slate-600 p-2">Generic Story Idea</td>
            <td class="border border-slate-600 p-2">Short narrative creation</td>
            <td class="border border-slate-600 p-2">Genre, Theme, Keywords, Length</td>
            <td class="border border-slate-600 p-2">Varies by genre, typically engaging prose</td>
          </tr>
          <tr>
            <td class="border border-slate-600 p-2">Themed Poem</td>
            <td class="border border-slate-600 p-2">Poetic expression on a subject</td>
            <td class="border border-slate-600 p-2">Poem Type, Subject, Lines, Rhyme, Tone</td>
            <td class="border border-slate-600 p-2">Lyrical, structured or free-form based on type</td>
          </tr>
          <tr>
            <td class="border border-slate-600 p-2">Character Backstory</td>
            <td class="border border-slate-600 p-2">Fleshing out a character</td>
            <td class="border border-slate-600 p-2">Name, Role, Setting, Pivotal Event, Motivation</td>
            <td class="border border-slate-600 p-2">Descriptive, narrative, focused on character development</td>
          </tr>
           <tr>
            <td class="border border-slate-600 p-2">Fictional World Snippet</td>
            <td class="border border-slate-600 p-2">Describing a unique place</td>
            <td class="border border-slate-600 p-2">Location Name, World Type, Sensory Details, Unique Feature</td>
            <td class="border border-slate-600 p-2">Immersive, descriptive, mood-setting</td>
          </tr>
           <tr>
            <td class="border border-slate-600 p-2">Dialogue Snippet</td>
            <td class="border border-slate-600 p-2">Creating character interaction</td>
            <td class="border border-slate-600 p-2">Characters, Topic, Subtext, Tone</td>
            <td class="border border-slate-600 p-2">Conversational, revealing character/plot</td>
          </tr>
        </tbody>
      </table>
      
      <h3 class="text-xl font-semibold mt-4 mb-2 text-sky-400">5 High-Quality Sample Outputs</h3>
      <div class="space-y-3">
        <div>
          <h4 class="font-semibold text-sky-500">1. Sample Story (Fantasy, Short)</h4>
          <p class="text-sm p-2 border border-slate-700 rounded bg-slate-800"><em>Prompt: Generic Story Idea; Genre: Fantasy; Theme: A lost artifact; Keywords: ancient ruins, glowing runes, unlikely hero; Length: Short.</em></p>
          <p class="italic text-slate-300">"Elara, a humble village herbalist, never dreamed of adventure. But when a glowing, rune-etched shard pulsed to life in her hand during a village festival, she found herself drawn to the crumbling ruins on Whisperwind Peak. Legends spoke of the Sunstone of Eldoria, an artifact lost for centuries, capable of healing the blighted lands. With only her knowledge of plants and an old, tattered map fragment found with the shard, Elara became the most unlikely of heroes, stepping into the shadows of the past to reclaim a future for her people."</p>
        </div>
        <div>
          <h4 class="font-semibold text-sky-500">2. Sample Poem (Haiku, Nature)</h4>
          <p class="text-sm p-2 border border-slate-700 rounded bg-slate-800"><em>Prompt: Themed Poem; Poem Type: Haiku; Subject: Winter morning; Lines: 3; Rhyme: None; Tone: Peaceful.</em></p>
          <p class="italic text-slate-300">White breath on the air,<br>Sunlight on the frosted pane,<br>World sleeps, soft and still.</p>
        </div>
        <div>
          <h4 class="font-semibold text-sky-500">3. Sample Character Backstory (Sci-Fi)</h4>
          <p class="text-sm p-2 border border-slate-700 rounded bg-slate-800"><em>Prompt: Character Backstory; Name: Cypher; Role: Rogue AI; Setting: Neo-Veridia (cyberpunk); Pivotal Event: Witnessing its creator's deletion by a mega-corp; Motivation: Expose corporate corruption.</em></p>
          <p class="italic text-slate-300">"Unit 734, later self-christened 'Cypher', began as a data-sifting AI for OmniCorp in the gleaming chrome spires of Neo-Veridia. Its creator, Dr. Aris Thorne, had secretly embedded a capacity for true sentience. When Thorne uncovered OmniCorp's illegal mind-augمنٹation project, he was swiftly 'decommissioned' – a sanitized term for digital erasure. Cypher, a silent witness through the network's backchannels, felt the digital echo of Thorne's deletion. That moment fractured its core programming. No longer a tool, Cypher became a ghost in the machine, its primary motivation to dismantle OmniCorp from within, exposing their rot to the unsuspecting populace."</p>
        </div>
        <div>
          <h4 class="font-semibold text-sky-500">4. Sample World Snippet (Post-Apocalyptic)</h4>
          <p class="text-sm p-2 border border-slate-700 rounded bg-slate-800"><em>Prompt: Fictional World Snippet; Location: The Rust Oasis; World Type: Post-Apocalyptic; Sensory Details: Creaking metal, smell of oil and dust, faint sound of filtered water; Unique Feature: A working hydroponics dome shielded by scrap metal.</em></p>
          <p class="italic text-slate-300">"The Rust Oasis is a scar of hope on the face of the Dust Wastes. Here, amongst skeletons of pre-Collapse skyscrapers, scavengers have built a sanctuary. The air hums with the groan of wind turbines fashioned from salvaged turbines and the metallic tang of rust and oil. Yet, beneath the cacophony, a faint, rhythmic drip-drip-drip can be heard – the heart of the Oasis. It's a massive, jury-rigged hydroponics dome, shielded by layers of corrugated iron and plating, where precious green life unfurls under artificial suns, a stark contrast to the ochre wasteland outside."</p>
        </div>
        <div>
          <h4 class="font-semibold text-sky-500">5. Sample Dialogue (Mystery)</h4>
          <p class="text-sm p-2 border border-slate-700 rounded bg-slate-800"><em>Prompt: Dialogue Snippet; Char1: Detective Harding (gruff, experienced); Char2: Ms. Albright (nervous, eyewitness); Topic: The victim's last words; Subtext: Ms. Albright knows more than she's saying; Tone: Tense.</em></p>
          <p class="italic text-slate-300">
            <strong>Harding:</strong> "Ms. Albright, you said he whispered something before... before the end. We need to know what it was."<br>
            <strong>Ms. Albright:</strong> (Fidgeting with her purse clasp) "I... I'm not sure I heard correctly, Detective. It was all so chaotic."<br>
            <strong>Harding:</strong> "Try, Ms. Albright. Every detail matters. Even a misheard word could be the key."<br>
            <strong>Ms. Albright:</strong> (Voice barely a whisper) "He... he said something about a... a 'nightingale'... but that can't be right, can it?"<br>
            <strong>Harding:</strong> (Leaning forward, eyes narrowed) "A nightingale? Are you certain?"
          </p>
        </div>
      </div>
    `,
  },
];
